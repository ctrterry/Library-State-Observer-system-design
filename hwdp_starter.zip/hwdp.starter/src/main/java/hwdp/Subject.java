package hwdp;

public interface Subject {
	// TODO HWDP P3
}
