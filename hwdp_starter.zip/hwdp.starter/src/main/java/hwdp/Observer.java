package hwdp;

public interface Observer {
	public void update(Subject o);
}
