package hwdp;

public class BadOperationException extends Exception {
    // TODO HWDP P2
}
