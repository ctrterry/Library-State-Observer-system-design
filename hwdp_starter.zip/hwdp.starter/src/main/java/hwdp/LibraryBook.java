package hwdp;
// TODO HWDP P2

public class LibraryBook /*implements Subject*/ {
    //                   ^ uncomment for P3
    private String name;
    // TODO? Are other instance variables needed for this pattern?
    
    
    public LibraryBook(String name) {
        // TODO HWDP P2
    }
    
    /*public LBState getState() {
        // TODO?
    }*/
    
    public void returnIt() {
        // TODO?
    }
    
    public void shelf() {
        // TODO?
    }
    
    public void extend() {
        // TODO?
    }
    
    public void issue() {
        // TODO?
    }
    
    /*@Override
    public String toString() {
        // TODO?
    }*/
}