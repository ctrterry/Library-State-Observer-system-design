package hwdp;
import java.util.ArrayList;

public class LibraryLogger {
    // TODO?

    public void writeLine(String line) {
        // TODO?
    }

    public String[] getWrittenLines() {
        // TODO?
        return null;
    }

    public void clearWriteLog() {
        // TODO?
    }
    
    public static LibraryLogger getInstance() {
        // TODO?
        return null;
    }
}
