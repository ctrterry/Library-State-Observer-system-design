package hwdp;

/**
 * Hello world!
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("Hello, this is the Design Patterns assignment in package hwdp!");
    }
}
