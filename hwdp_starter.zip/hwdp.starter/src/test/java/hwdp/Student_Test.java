package hwdp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class Student_Test {

    @Test
    void myStudentTest(){
        assertEquals(2,2);
    }  
}
