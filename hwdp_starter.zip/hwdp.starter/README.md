ECS 160

Please see the post on canvas for full description